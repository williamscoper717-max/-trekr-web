import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router";
import heart from "/images/heart.svg";
import photo from "/images/photo.jpg";
import photo2 from "/images/photo-2.jpg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowUpRightFromSquare, faBuilding, faCalendar, faCamera, faClock, faCloudSun,  faLeaf, faLightbulb, faMap, faPen, faStar, faTrainSubway } from "@fortawesome/free-solid-svg-icons";
import React from "react";
import { useUser } from "@/context/userContext";
import axiosInstance from "@/api/config";
import { calculateDurationDays, capitalizeWords, formatDateRange, getDate } from "@/assets/helpers";
import Map from "@/components/navbar/map";
import Suggestions from "./suggestions";
import Slider from "./slider";
import Button from "./button";

interface Trip{
    id: number,
    name: string,
    type: string,
    country: string,
    destination: string,
    budget: string,
    start_date: Date,
    end_date: Date,
    adult: number,
    transportation: string,
    children: number
}

interface Schedule{
    morning: any;
    afternoon: any;
    evening: any;
}

interface Day{
    title: string;
    schedule: Schedule;
}

interface Program{
    id: number;
    days: number;
    accommodation: any;
    itinerary: {
        days: Day[];
    };
    trip_id: number;
}

interface Tip{
    id: number;
    ecofriendly_tips: [];
    local_transport_options: [];
    trip_id: number;
}

interface Food{
    id: number;
    items: [];
    name: string;
    slug: string;
}

export default function Details(){
    const navigate = useNavigate();
    const { auth, loading, sidebarOpen, setSidebarOpen } = useUser(); 
    const { id } = useParams();
    const [trip, setTrip] = useState<Trip | null>(null);
    const [program, setProgram] = useState<Program | null>(null);
    const [tip, setTip] = useState<Tip | null>(null);
    const [food, setFood] = useState<Food[]>([]);
    const [selectedDayIndex, setSelectedDayIndex] = useState(0);
    useEffect(() => {
        if(!loading && !auth){
          navigate("/");
        }
    }, [auth, loading, navigate]);

    useEffect(() => {
        const getTrip = async () =>{
            if (!id) return;
            
            const response = await axiosInstance.post("trips/first", {id});
            
            if(response.status === 200){
                const data = response.data;
                // Support both old and new format
                if (data.success && data.data && data.data.travel_package) {
                    setTrip(data.data.travel_package);
                } else {
                    setTrip(data.trip);
                }
            }
        }

        getTrip()
    }, [id]);
    
    const slides = [
        { image: photo, text_1: "Vieux Lyon", text_2: "Découverte des traboules historiques" },
        { image: photo2, text_1: "Balade à Vélo", text_2: "Le long du Rhône au coucher du soleil" }
    ];

    useEffect(() => {
        const getProgram = async () =>{
            if (!id) return;
            
            const response = await axiosInstance.post('program/get', {id});
            
            if(response.status === 200){
                setProgram(response.data.program);
            }
        }

        getProgram()
    }, [id]);

    useEffect(() => {
        const getFood = async () => {
            const response = await axiosInstance.get("adems/alimentation", {
      params: { category: "group", language: "fr" }
    });
            console.log(response.data);
        };

        getFood();
    }, []);

    useEffect(() => {
        const getTip = async () =>{
            if (!id) return;
            
            const response = await axiosInstance.post("tip/get", {id});
            
            if(response.status === 200){
                const data = response.data;
                // Support both old and new format
                if (data.success && data.data && data.data.travel_package) {
                    setTip({
                        id: data.data.travel_package.id || 0,
                        ecofriendly_tips: data.data.travel_package.ai_enhanced_recommendations || [],
                        local_transport_options: data.data.travel_package.bookable_components?.transport || [],
                        trip_id: data.data.travel_package.id || 0
                    } as any);
                } else {
                    setTip(data.tip);
                }
            }
        }

        getTip()
    }, [id]);
    
    return(
        <div>
            <div className='flex relative'>
                {trip && 
                    <div className='bg-main rounded-r-lg w-full lg:px-20 px-5'>
                        <h2 className="text-2xl sm:text-2xl lg:text-4xl text-center mt-3 font-semibold">
                            <span className="text-blue-950">
                                {capitalizeWords(trip.name)}
                            </span>
                        </h2>
                        <h2 className="text-base sm:text-lg lg:text-xl text-center mt-3 font-semibold">
                            <div className="text-gray-500 flex place-content-center items-center">
                                <div>{capitalizeWords(trip.destination)}</div>
                                <div className="w-1 h-1 bg-gray-500 rounded-full mx-2 font-bold mt-1"></div>
                                <div>{formatDateRange(trip.start_date, trip.end_date)}</div>
                            </div>
                        </h2>
                        <div className="my-5 border border-gray-300 bg-white raduis p-4">
                            <div className="flex items-center justify-around">
                                <div className="text-center">
                                    <div className="text-blue-950 font-bold text-lg lg:text-2xl">{calculateDurationDays(trip.start_date, trip.end_date)}</div>
                                    <div className="text-gray-500 text-sm mt-1">Jours</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-green-600 font-bold text-lg lg:text-2xl">245 kg</div>
                                    <div className="text-gray-500 text-sm mt-1">CO₂ économisé</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-blue-950 font-bold text-lg lg:text-2xl">{trip.budget} €</div>
                                    <div className="text-gray-500 text-sm mt-1">Budget total</div>
                                </div>
                            </div>
                        </div>
                        <div className="my-5 grid gap-4 grid-cols-4 md:grid-cols-6">
                            {program?.itinerary.days.map((day, index) => (
                                <div 
                                    className={`py-2 border rounded-2xl font-semibold text-sm link-hover cursor-pointer w-20 lg:w-28 text-center mr-2 ${index === selectedDayIndex ? 'bg-blue-950 text-white' : 'text-blue-950'}`}
                                    key={index}
                                    onClick={() => setSelectedDayIndex(index)}
                                >
                                    <FontAwesomeIcon icon={faCalendar}/> <span className="ms-2">{`Jour ${index + 1}`}</span>
                                </div>
                            ))}
                        </div>
                        {/* <div className="max-w-5xl mx-auto my-5"> */}
                        <div className="mx-auto my-5">
                            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                                <div className="col-span-1 md:col-span-7">
                                    <div className="border border-gray-300 bg-white raduis p-4">
                                        <div className="flex items-center justify-between mb-4">
                                            <div className="text-blue-950 font-semibold">{getDate(trip.start_date, selectedDayIndex)}</div>
                                            <div className="text-blue-950 font-semibold"><FontAwesomeIcon icon={faCloudSun} className="text-2xl" /> 15</div>
                                        </div>
                                    </div>
                                    <div className="border border-gray-300 bg-white raduis p-4 mt-5">
                                        <div className="text-blue-950 font-semibold">
                                            <FontAwesomeIcon icon={faTrainSubway} /> 
                                            <span className="ms-2">Transport</span>
                                        </div>
                                        <div className="flex items-center justify-between mb-4">
                                            <div>
                                                <span className="text-blue-950 font-semibold">{trip.transportation === "car" ? "Voiture" : trip.transportation === "train" ? "Train" : "Avion"}</span>
                                                <span className="ms-2 text-blue-950 font-semibold">{capitalizeWords(trip.destination)}</span>
                                                <div className="text-gray-500 text-sm">6h</div>
                                            </div>
                                            <div>
                                                <div className="text-blue-950 font-semibold text-trip-color">-85 kg</div>
                                                <div className="text-blue-950 text-right">89€</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="border border-gray-300 bg-white raduis p-4 mt-5">
                                        <div className="text-blue-950 font-semibold">
                                            <FontAwesomeIcon icon={faBuilding} /> 
                                            <span className="ms-2">Hébergement</span>
                                        </div>
                                        <span className="text-blue-950 font-semibold">{program && program.accommodation.name}</span>
                                        <span className="ms-2 text-blue-950 font-semibold">{capitalizeWords(trip.destination)}</span>
                                        <div className="flex items-center justify-between mb-4">
                                            <div>
                                                <div className="text-gray-500 text-sm">Vieux Lyon</div>
                                                <div className="text-sm flex items-center mt-1">
                                                    <FontAwesomeIcon icon={faStar} color={"#FFCD4F"} />
                                                    <span className="ms-1 text-blue-950">{program && program.accommodation.rating}</span>
                                                    <div className="bg-trip text-trip-color text-xs font-semibold rounded-xl py-1 px-3 ms-4">
                                                        <FontAwesomeIcon icon={faLeaf} /> Eco
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="mt-2">
                                                <div className="text-blue-950 text-center font-semibold">{program && program.accommodation.price_per_night}€/nuit</div>
                                                <div className={`py-2 border rounded-2xl font-semibold text-sm link-hover cursor-pointer w-28 text-center me-2 text-blue-950 mt-1`}>
                                                    <FontAwesomeIcon icon={faArrowUpRightFromSquare}/> <span className="ms-2">Réserver</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <h2 className="text-blue-950 text-lg font-bold my-5">Activités du jour</h2>
                                    {program && program.itinerary.days[selectedDayIndex] &&
                                        ['morning', 'afternoon', 'evening'].map((period) => {
                                            const activity = program.itinerary.days[selectedDayIndex].schedule[period];
                                            return (
                                                <div key={period} className="border border-gray-300 bg-white raduis p-4 mt-5">
                                                    <div className="text-gray-500 w-24 mb-3 ml-3">
                                                        <FontAwesomeIcon icon={faClock} />
                                                        <span className="ml-1">{period.charAt(0).toUpperCase() + period.slice(1)}</span>
                                                    </div>
                                                    <div className="flex mb-4 text-sm">
                                                        <div className="ml-3 flex-1 w-100">
                                                            <div className="flex items-start justify-between w-full">
                                                                <div className="flex items-start mb-2">
                                                                    <FontAwesomeIcon icon={faCamera} className="text-blue-950 me-2 text-sm mt-1" />
                                                                    <h2 className="text-blue-950 font-bold">{activity.activity}</h2>
                                                                </div>
                                                                <div className="flex items-start text-blue-950 text-sm">
                                                                    <div className="cursor-pointer py-1 px-3 rounded-full link-hover">
                                                                        <FontAwesomeIcon icon={faPen}/>
                                                                    </div>
                                                                    <div className="ms-3 cursor-pointer link-hover py-1 px-3 rounded-full">
                                                                        <FontAwesomeIcon icon={faArrowUpRightFromSquare}/> 
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="text-sm text-gray-500">{activity?.description || "Découverte des traboules"}</div>
                                                            <div className="flex items-center mt-2">
                                                                <div className="text-xs text-blue-950">{activity?.duration || "3h"}</div>
                                                                <div className="text-xs text-green-600 mx-5">{activity?.weight || "0 kg"}</div>
                                                                <div className="text-xs text-green-950 font-semibold">{activity.cost != 0 ? activity.cost + "€" : "Gratuit" }</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })
                                    }
                                    <div className="border border-gray-300 bg-white raduis p-4 mt-5">
                                        <div className="flex items-center mb-4">
                                            <FontAwesomeIcon icon={faMap} className="text-green-600"/>
                                            <span className="ms-2 font-semibold text-blue-950">Points d'Intérêt</span>
                                        </div>
                                        <div>
                                            <Map/>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-span-1 md:col-span-5">
                                    <div className="border border-gray-300 bg-white raduis p-4">
                                        <div className="flex items-center mb-4">
                                            <img src={heart} alt="heart" />
                                            <div className="text-blue-950 font-semibold ms-2">Inspirations Voyage</div>
                                        </div>
                                        <Slider slides={slides} />
                                    </div>
                                    <div className="border border-gray-300 bg-white raduis p-4 mt-5">
                                        <div className="flex items-center mb-4">
                                            <FontAwesomeIcon icon={faLightbulb} className="text-yellow-300"/>
                                            <div className="text-blue-950 font-semibold ms-2">Astuces Locales</div>
                                        </div>
                                        <Suggestions tip={tip}/>
                                    </div>
                                    <div className="border border-gray-300 bg-white raduis p-4 mt-5">
                                        <div className="mb-4">
                                            <div className="text-blue-950 font-semibold ms-2">Actions</div>
                                        </div>
                                        <div className={`py-2 border rounded-2xl font-semibold text-sm link-hover cursor-pointer w-full text-center me-2 text-blue-950 mt-2`}>
                                            <FontAwesomeIcon icon={faPen}/> <span className="ms-2">Modifier le voyage</span>
                                        </div>
                                        <div className={`py-2 border rounded-2xl font-semibold text-sm link-hover cursor-pointer w-full text-center me-2 text-blue-950 mt-2`}>
                                            <FontAwesomeIcon icon={faArrowUpRightFromSquare}/> <span className="ms-2">Partager l'itinéraire</span>
                                        </div>
                                        <div className={`py-2 border rounded-2xl font-semibold text-sm cursor-pointer w-full text-center me-2 text-white bg-blue-950 mt-2 hover:opacity-80`}>
                                            <FontAwesomeIcon icon={faStar} color={"#fff"}/> <span className="ms-2">Partager l'itinéraire</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <Button trip={trip.destination}/>
                    </div>
                }
            </div>
        </div>
    )
}