from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class UserResponse(BaseModel):
    id: int
    email: str
    name: str
    phone: Optional[str] = None
    email_verified_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str
    
class TokenUser(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse