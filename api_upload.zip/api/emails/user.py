from fastapi_mail import MessageSchema, ConnectionConfig, FastMail
from schemas.user import EmailRequest
from fastapi_mail import MessageSchema, MessageType
from email.mime.text import MIMEText
from fastapi import HTTPException
from config import (
    MAIL_FROM, MAIL_FROM_NAME, MAIL_PASSWORD, MAIL_PORT, 
    MAIL_SERVER, MAIL_USERNAME, MAIL_TLS, MAIL_SSL
)

data = ConnectionConfig(
    MAIL_USERNAME=MAIL_USERNAME,
    MAIL_PASSWORD=MAIL_PASSWORD,
    MAIL_FROM=MAIL_FROM,
    MAIL_PORT=MAIL_PORT,
    MAIL_SERVER=MAIL_SERVER,
    MAIL_FROM_NAME=MAIL_FROM_NAME,
    MAIL_STARTTLS=MAIL_TLS,
    MAIL_SSL_TLS=MAIL_SSL,
    USE_CREDENTIALS=True,
    VALIDATE_CERTS=True
)

mail = FastMail(data)

async def send_email(subject: str, recipient: str, body: str):
    message = MessageSchema(
        subject=subject,
        recipients=[recipient],  # Updated from recipient to recipients (notice the 's')
        body=body,
        subtype="html"
    )
    try:
        await mail.send_message(message)
        print("Email sent successfully")
    except Exception as e:
        print(f"Error sending email: {e}")
        
async def send_email_contact(email_data: EmailRequest):
    try:
        html = f"""
        <h3>Nouveau message depuis le formulaire de contact</h3>
        <p><b>Nom:</b> {email_data.name}</p>
        <p><b>Email:</b> {email_data.email}</p>
        <p><b>Sujet:</b> {email_data.subject}</p>
        <p><b>Message:</b><br>{email_data.message}</p>
        """

        message = MessageSchema(
            subject=f"Contact Form: {email_data.subject}",
            recipients=[MAIL_FROM],  # send to yourself
            body=html,
            subtype=MessageType.html
        )

        await mail.send_message(message)
        return {"message": "Email sent successfully"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
