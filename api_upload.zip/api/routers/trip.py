from fastapi import APIRouter, Depends
from schemas.trip import TripOut, TripCreate, TripResponse, TripUser
from sqlalchemy.orm import Session
from database import get_db
from services.trip import create_trip, get_trips, get_trip, get_latest_trip, get_emission_summary_by_user
from fastapi import Request
from helpers import my_public_ip
import httpx

router = APIRouter()

@router.post("/create/", response_model=TripOut)
async def save_trip(trip: TripCreate, db: Session = Depends(get_db)):
    db_trip = await create_trip(trip=trip, db=db)
    return db_trip

@router.get("/get")
async def get_user_trips(user_id: int, db: Session = Depends(get_db)):
    # Call the get_trip function with the user_id
    return await get_trips(user_id=user_id, db=db)

@router.post("/first")
async def get_user_trip(trip_request: TripResponse, db: Session = Depends(get_db)):
    # Pass trip_request.trip_id instead of trip_id
    return await get_trip(id=trip_request.id, db=db)

@router.post("/latest")
async def get_user_latest_trip(request: TripUser, db: Session = Depends(get_db)):
    return await get_latest_trip(user_id=request.user_id, db=db)

@router.get("/get-ip")
async def get_ip(request: Request):
    # Get the real public IP of the server (useful in localhost)
    ip_to_lookup = await my_public_ip()  # <-- You must await this!

    async with httpx.AsyncClient() as client:
        response = await client.get(f"https://ipapi.co/{ip_to_lookup}/json/")
        ip_data = response.json()

    return {
        "client_ip": ip_to_lookup,
        "ip_info": ip_data
    }
    
@router.get("/emission-summary")
async def emission_summary(db: Session = Depends(get_db)):
    return await get_emission_summary_by_user(db)