from models.trip import Trip
from models.user import User
from models.program import Program
from models.tip import Tip
from sqlalchemy.orm import Session, joinedload
from fastapi.responses import JSONResponse
from fastapi import HTTPException, status
from sqlalchemy.exc import IntegrityError
from database import db_dependency
from datetime import date
from sqlalchemy import desc
from helpers import get_itinerary_data, validate_itinerary_response
from sqlalchemy import func

async def create_trip(trip: Trip, db: Session) -> JSONResponse:
    # Input validation before database operations
    if not trip.name or not trip.destination or not trip.budget or not trip.start_date or not trip.end_date  or not trip.num_adult:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="All fields are required"
        )
    
    name = trip.name.lower()
    destination = trip.destination.lower()
    country = trip.country.lower()
    note = trip.note.lower() if trip.note else None
    
    try:
        # utilisation de l'api IA
        get_itinerary = get_itinerary_data(
            transportation=trip.transportation,
            language=trip.language,
            origin=country,
            destination=destination,
            budget=trip.budget,
            days=(trip.end_date - trip.start_date).days,
            num_people=trip.num_adult + trip.num_children
        )
        # print(get_itinerary)
        validate_itinerary_response(get_itinerary)
        # if not get_itinerary or 'itinerary' not in get_itinerary:
        #     raise ValueError(
        #         f"Invalid itinerary data received from IA API. "
        #         f"Response: {get_itinerary}"
        #     )

        # Support both old and new format
        if "data" in get_itinerary and "travel_package" in get_itinerary["data"]:
            pkg = get_itinerary["data"]["travel_package"]
            travel_emission = pkg.get("sustainability_analysis", {}).get("total_carbon_footprint_kg", 0)
            accommodation = pkg.get("bookable_components", {}).get("accommodation", {})
            itinerary = {"days": pkg.get("daily_itinerary", [])}
            tips = pkg.get("ai_enhanced_recommendations", [])
            local_transport = pkg.get("bookable_components", {}).get("transport", [])
        else:
            travel_emission = get_itinerary['itinerary']['travel_co2_emission']
            accommodation = get_itinerary['itinerary']['accommodation']
            itinerary = get_itinerary['itinerary']['itinerary']
            tips = get_itinerary['itinerary']['ecofriendly_tips']
            local_transport = get_itinerary['itinerary']['local_transport_options']

    except Exception as e:
        print("❌ IA response error:", str(e))
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"IA response format is incompatible with backend expectations: {str(e)}"
        )
    
    db_trip = Trip(
        name=name,
        type=trip.type,
        country=country,
        destination=destination,
        transportation=trip.transportation,
        budget=trip.budget,
        start_date=trip.start_date,
        end_date=trip.end_date,
        num_adult=trip.num_adult,
        num_children=trip.num_children,
        note=note,
        carbon_emission=travel_emission,
        with_visa=trip.with_visa,
        user_id=trip.user_id
    )
    
    try:
        db.add(db_trip)
        db.commit()
        db.refresh(db_trip)
        
        program_data = {
            "days": (trip.end_date - trip.start_date).days,
            "accommodation": accommodation,
            "itinerary": itinerary,
            "trip_id": db_trip.id
        }
        
        db_program = Program(**program_data)
        db.add(db_program)
        
        tips_data = {
            "ecofriendly_tips": tips,
            "local_transport_options": local_transport,
            "trip_id": db_trip.id
        }
        
        db_tip = Tip(**tips_data)
        db.add(db_tip)
        
        db.commit()
        
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error: Unable to create trip"
        )
    
    return JSONResponse(
        status_code=status.HTTP_201_CREATED,
        content={
            "status": "success",
            "message": "Votre voyage a été crée avec succès",
            "trip": {
                "id": db_trip.id,
            }
        }
    )
    
async def get_trips(user_id: int, db: Session = db_dependency) -> JSONResponse:
    db_trips = db.query(Trip).filter(Trip.user_id == user_id).order_by(desc(Trip.created_at)).all()

    if not db_trips:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No trips found")
    
    trip_data = [
        {
            "id": trip.id,
            "name": trip.name,
            "type": trip.type,
            "country": trip.country,
            "destination": trip.destination,
            "transportation": trip.transportation,
            "image": trip.image,
            "status": trip.status,
            "budget": int(float(trip.budget)) if trip.budget is not None else None,
            "start_date": trip.start_date.strftime('%Y-%m-%d') if isinstance(trip.start_date, date) else trip.start_date,
            "end_date": trip.end_date.strftime('%Y-%m-%d') if isinstance(trip.end_date, date) else trip.end_date,
            "adult": trip.num_adult,
            "children": trip.num_children,
            "note": trip.note,
            "user_id": trip.user_id,
            "carbon_emission": trip.carbon_emission,
        }
        for trip in db_trips
    ]

    return JSONResponse(status_code=status.HTTP_200_OK, content={"trips": trip_data})

async def get_trip(id:int, db:Session = db_dependency)-> JSONResponse:
    db_trip = db.query(Trip).filter(Trip.id == id).order_by(desc(Trip.created_at)).first()
    
    if not db_trip:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Trip not found"
        )
    total_emission = db.query(func.sum(Trip.carbon_emission))\
    .filter(Trip.user_id == db_trip.user_id)\
    .scalar() or 0
    
    trip_data = {
        "id": db_trip.id,
        "name": db_trip.name,
        "type": db_trip.type,
        "country": db_trip.country,
        "destination": db_trip.destination,
        "transportation": db_trip.transportation,
        "budget": db_trip.budget,
        "start_date": db_trip.start_date.strftime('%Y-%m-%d') if isinstance(db_trip.start_date, date) else db_trip.start_date,
        "end_date": db_trip.end_date.strftime('%Y-%m-%d') if isinstance(db_trip.end_date, date) else db_trip.end_date,
        "adult": db_trip.num_adult,
        "children": db_trip.num_children,
        "note": db_trip.note,
        "carbon_emission": db_trip.carbon_emission,
        "total_carbon_emission": total_emission,
        "user_id": db_trip.user_id,
    }
    
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={"status": "success", "trip" : trip_data}
    )
    
async def get_latest_trip(user_id:int, db:Session = db_dependency)-> JSONResponse:
    db_trip = db.query(Trip).filter(Trip.user_id == user_id).order_by(desc(Trip.created_at)).first()
    
    if not db_trip:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Trip not found"
        )
    
    total_emission = db.query(func.sum(Trip.carbon_emission))\
    .filter(Trip.user_id == user_id)\
    .scalar() or 0
     
    trip_data = {
        "id": db_trip.id,
        "name": db_trip.name,
        "type": db_trip.type,
        "country": db_trip.country,
        "destination": db_trip.destination,
        "transportation": db_trip.transportation,
        "budget": int(float(db_trip.budget)) if db_trip.budget is not None else None,
        "start_date": db_trip.start_date.strftime('%Y-%m-%d') if isinstance(db_trip.start_date, date) else db_trip.start_date,
        "end_date": db_trip.end_date.strftime('%Y-%m-%d') if isinstance(db_trip.end_date, date) else db_trip.end_date,
        "adult": db_trip.num_adult,
        "children": db_trip.num_children,
        "note": db_trip.note,
        "user_id": db_trip.user_id,
        "carbon_emission": db_trip.carbon_emission,
        "total_carbon_emission": total_emission
    }
    
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={"status": "success", "trip" : trip_data}
    )
    
async def get_emission_summary_by_user(db: Session = db_dependency) -> JSONResponse :
    results = (
        db.query(
            User.id.label("user_id"),
            User.name.label("user_name"),
            func.sum(Trip.carbon_emission).label("total_emission")
        )
        .join(Trip, Trip.user_id == User.id)
        .group_by(User.id)
        .order_by(func.sum(Trip.carbon_emission).asc())
        .all()
    )

    data = [
        {
            "user_id": row.user_id,
            "rank": index + 1,
            "user_name": row.user_name,
            "total_emission": round(row.total_emission, 2)
        }
        for index, row in enumerate(results)
    ]

    return JSONResponse(
        status_code=200,
        content={
            "total_users": len(data),
            "emissions": data
        }
    )