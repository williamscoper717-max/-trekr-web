from sqlalchemy.orm import Session
from database import db_dependency
from fastapi.responses import JSONResponse
from models.program import Program
from fastapi import HTTPException, status

async def get_program(trip_id: int, db: Session = db_dependency) -> JSONResponse:
    db_program = db.query(Program).filter(Program.trip_id == trip_id).first()
    
    if not db_program :
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Program not found"
        )
        
    program_data = {
        "id": db_program.id,
        "days": db_program.days,
        "accommodation": db_program.accommodation,
        "itinerary": db_program.itinerary,
        "trip_id": db_program.trip_id,
    }
    
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={"status": "success", "program" : program_data}
    )
    