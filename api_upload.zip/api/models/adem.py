from sqlalchemy import Column, Integer, TIMESTAMP, text, String
from database import Base

class Adem(Base):
    __tablename__ = "adems"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    total_carbon = Column(Integer, index=True)
    