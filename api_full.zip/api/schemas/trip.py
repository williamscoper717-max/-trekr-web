from pydantic import BaseModel
from datetime import date
from typing import Optional

# Pydantic model for user registration (input validation)
class TripCreate(BaseModel):
    name: str
    type: str
    country: str
    destination: str
    transportation: str
    language: str
    budget: int
    start_date: date
    end_date: date
    num_adult: int
    num_children: Optional[int] = None
    note: Optional[str] = None
    carbon_emission: Optional[float] = None
    with_visa: Optional[bool] = None
    user_id: int

# Pydantic model for user responses
class TripOut(TripCreate):
    id: int

    class Config:
        from_attributes = True
        
class TripResponse(BaseModel):
    id: int

    class Config:
        from_attributes = True
        
class TripUser(BaseModel):
    user_id: int

    class Config:
        from_attributes = True

