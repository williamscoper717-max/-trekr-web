from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional

# Pydantic model for user registration (input validation)
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    phone: Optional[str] = None
    password: str
    email_verified_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        # orm_mode = True
        from_attributes = True

# Pydantic model for user responses
class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    token: str
    email_verified_at: Optional[datetime] = None
    phone: Optional[str] = None
    biography: Optional[str] = None
    
    class Config:
        # orm_mode = True
        from_attributes = True

class UserUpdate(BaseModel):
    id: int
    name: str
    email: str
    phone: Optional[str]
    biography: Optional[str]
    picture: Optional[str]

    class Config:
        from_attributes = True
        
class LoginForm(BaseModel):
    email: str
    password: str
    
class Token(BaseModel):
    token: str
    token_type: str
    
class TokenData(BaseModel):
    username: str | None = None
    scopes: list[str] = []

class EmailRequest(BaseModel):
    name: str
    email: EmailStr
    subject: str
    message: str