from pydantic import BaseModel
from typing import Dict

class ProgramOut(BaseModel):
    id: int
    days: int
    accommodation: Dict
    itinerary: Dict
    trip_id: int
    
    class Config:
        # orm_mode = True
        from_attributes = True

class ProgramRequest(BaseModel):
    trip_id: int