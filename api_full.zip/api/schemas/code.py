from pydantic import BaseModel, EmailStr

class CodeCreate(BaseModel):
    code: str
    user_email: EmailStr
    
    class Config:
        # orm_mode = True
        from_attributes = True
        
class CodeOut(BaseModel):
    id: int
    code: str
    user_id: int
    
    class Config:
        # orm_mode = True
        from_attributes = True
        
class VerificationRequest(BaseModel):
    code: str
    email: EmailStr