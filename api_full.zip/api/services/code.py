from models.code import Code, Base
from models.user import User
from database import engine
from helpers import generate_code
from fastapi import HTTPException, status
from datetime import datetime
from sqlalchemy.orm import Session
from schemas.code import CodeOut

Base.metadata.create_all(bind=engine)

# Generate and store a verification code
async def create_code(user_id: int, db: Session) -> int:
    code = int(generate_code())
    
    # Invalidate previous codes for the user (Optional)
    db.query(Code).filter(Code.user_id == user_id).delete()
    
    db_code = Code(code=code, user_id=user_id)
    db.add(db_code)
    db.commit()
    db.refresh(db_code)
    
    return code

# Verify the code and update the user's verification status
# async def verify_code(code: int, user_email: str, db: Session) -> CodeOut:
#     if not isinstance(code, int) or not isinstance(user_email, str):
#         raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid input types")
    
#     user = db.query(User).filter(User.email == user_email).first()
    
#     if not user:
#         raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    
#     existing_code = db.query(Code).filter(Code.code == code, Code.user_id == user.id).first()
    
#     if not existing_code:
#         raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Incorrect code")
    
#     try:
#         user.email_verified_at = datetime.now()
#         db.add(user)
#         db.delete(existing_code)
#         db.commit()
#         db.refresh(user)
        
#         # Return the CodeOut instance after verification
#         return CodeOut(id=existing_code.id, code=existing_code.code, user_id=existing_code.user_id)
#     except Exception as e:
#         db.rollback()
#         raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Verification failed")

async def verify_code(code: str, user_email: str, db: Session) -> User:
    if not isinstance(code, str) or not isinstance(user_email, str):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid input types")
    
    # Fetch the user based on email
    user = db.query(User).filter(User.email == user_email).first()
    
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    
    # Fetch the existing code
    existing_code = db.query(Code).filter(Code.code == code, Code.user_id == user.id).first()
    
    if not existing_code:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Incorrect code")
    
    try:
        # Update the user's email verification status
        user.email_verified_at = datetime.now()
        db.add(user)
        db.delete(existing_code)
        db.commit()
        db.refresh(user)
        
        # Return the user object for token generation
        return user
    
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Verification failed")
