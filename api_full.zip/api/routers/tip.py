from fastapi import APIRouter, Depends
from schemas.trip import TripResponse
from sqlalchemy.orm import Session
from database import get_db
from services.tip import get_tip

router = APIRouter()
@router.post("/get")
async def get_trip_tip(tip_request: TripResponse, db: Session = Depends(get_db)):
    return await get_tip(trip_id=tip_request.id, db=db)