from fastapi import APIRouter, Depends
from schemas.trip import TripResponse
from sqlalchemy.orm import Session
from database import get_db
from services.program import get_program

router = APIRouter()
@router.post("/get")
async def get_trip_program(program_request: TripResponse, db: Session = Depends(get_db)):
    return await get_program(trip_id=program_request.id, db=db)