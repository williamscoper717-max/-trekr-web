from fastapi import APIRouter, Depends, status, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from schemas.user import UserCreate, UserOut, LoginForm, UserUpdate, EmailRequest
from models.user import User
from services.user import create_user, get_current_user, authenticate_user,create_jwt_token, create_google_user, update_user
from database import get_db
from helpers import create_access_token, verify_google_token
from datetime import timedelta
from config import ACCESS_TOKEN_EXPIRE_MINUTES
import logging
from typing import Optional
from emails.user import send_email_contact

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post("/register/", response_model=UserOut)
async def register_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = await create_user(user=user, db=db)
    return db_user

@router.get("/profile")
async def get_current_user_data(current_user: User = Depends(get_current_user)):
    return current_user

@router.post("/login")
async def login_for_access_token(payload: LoginForm, db: Session = Depends(get_db)):
    try:
        user = await authenticate_user(email=payload.email, password=payload.password, db=db)
        access_token = create_access_token(
            data={"sub": str(user.id)},
            expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        )
        return {"access_token": access_token, "token_type": "bearer", "user": user}
    except HTTPException as e:
        # Pass HTTPException to the frontend
        raise e

@router.post("/auth/google-token")
async def auth_google_token(data: dict, db: Session = Depends(get_db)):
    id_token = data.get("id_token")
    if not id_token:
        raise HTTPException(status_code=400, detail="Missing ID token")

    # Step 1: Verify Google token and extract email and name
    google_data = verify_google_token(id_token)
    email = google_data["email"]
    name = google_data["name"]

    # Step 2: Fetch or create user
    user = db.query(User).filter(User.email == email).first()
    if not user:
        user = await create_google_user(name, email, db)

    # Step 3: Generate a new JWT for frontend use
    jwt_token = create_jwt_token(user.email)

    return {"user": user.email, "token": jwt_token}

@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout():
    return {"message": "Logged out successfully", "status": "success"}

@router.post("/update/", response_model=UserUpdate)
async def update(
    id: int = Form(...),  # assuming id is mandatory for identifying user to update
    name: Optional[str] = Form(None),
    email: Optional[str] = Form(None),
    phone: Optional[str] = Form(None),
    biography: Optional[str] = Form(None),
    password: Optional[str] = Form(None),
    picture: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
):
    db_user = await update_user(
        id=id,
        name=name,
        email=email,
        phone=phone,
        biography=biography,
        password=password,
        picture=picture,
        db=db,
    )
    return db_user

@router.post("/send-email")
async def send_email(data: EmailRequest):
    await send_email_contact(data)