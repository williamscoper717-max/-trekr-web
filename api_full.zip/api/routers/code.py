from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from schemas.code import CodeCreate
from services.code import verify_code
from database import get_db
from schemas.token import Token, TokenUser
from datetime import timedelta
from config import ACCESS_TOKEN_EXPIRE_MINUTES
from helpers import create_access_token

router = APIRouter()

# @router.post("/verification/", response_model=CodeOut)
# async def verify_user(code: CodeCreate, db: Session = Depends(get_db)):
#     return await verify_code(code=code.code, user_email=code.user_email, db=db)

# @router.post("/verification/")
# async def verify_user(code: CodeCreate, db: Session = Depends(get_db)):
#     response = await verify_code(code=code.code, user_email=code.user_email, db=db)
#     return response  # Return the success message to the frontend
@router.post("/verification", response_model=Token)
async def verify_user(payload: CodeCreate, db: Session = Depends(get_db)):
    user = await verify_code(code=payload.code, user_email=payload.user_email, db=db)
    access_token = create_access_token(
        data={"sub": str(user.id)},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return {"access_token": access_token, "token_type": "bearer"}
    
@router.post("/verificationUser", response_model=TokenUser)
async def verify_user_code(payload: CodeCreate, db: Session = Depends(get_db)):
    user = await verify_code(code=payload.code, user_email=payload.user_email, db=db)
    access_token = create_access_token(
        data={"sub": str(user.id)},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user
    }