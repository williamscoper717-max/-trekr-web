from sqlalchemy import Column, Integer, String, TIMESTAMP, text, Text
from sqlalchemy.orm import relationship
from database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    email = Column(String, unique=True, index=True)
    phone = Column(String, unique=True, index=True, nullable=True)
    password = Column(String)
    email_verified_at = Column(TIMESTAMP(timezone=True), nullable=True)
    biography = Column(Text, nullable=True)
    created_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'))
    updated_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'), server_onupdate=text('now()'))
    biography = Column(Text, nullable=True)
    picture = Column(Text, nullable=True)
    
    codes = relationship("Code", back_populates="user")
    trips = relationship("Trip", back_populates="user")
