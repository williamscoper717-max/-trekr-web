from database import Base
from sqlalchemy import Column, Integer, TIMESTAMP, text, ForeignKey, JSON
from sqlalchemy.orm import relationship

class Tip(Base):
    __tablename__ = "tips"
    id = Column(Integer, primary_key=True, index=True)
    ecofriendly_tips = Column(JSON, index=True)
    local_transport_options = Column(JSON, index=True)
    trip_id = Column(Integer, ForeignKey('trips.id'), index=True)
    created_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'))
    updated_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'), server_onupdate=text('now()'))

    trip = relationship('Trip', back_populates='tips')