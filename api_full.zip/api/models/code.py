from sqlalchemy import Column, Integer, TIMESTAMP, text, ForeignKey
from sqlalchemy.orm import relationship
from database import Base

class Code(Base):
    __tablename__ = "codes"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(Integer, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    created_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'))
    updated_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'), server_onupdate=text('now()'))
    
    user = relationship("User", back_populates="codes")