from database import Base
from sqlalchemy import Column, Integer, TIMESTAMP, text, ForeignKey, JSON
from sqlalchemy.orm import relationship

class Program(Base):
    __tablename__ = "programs"
    id = Column(Integer, primary_key=True, index=True)
    days = Column(Integer, index=True)
    accommodation = Column(JSON, index=True)
    itinerary = Column(JSON, index=True)
    trip_id = Column(Integer, ForeignKey('trips.id'), index=True)
    created_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'))
    updated_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'), server_onupdate=text('now()'))

    trip = relationship('Trip', back_populates='programs')