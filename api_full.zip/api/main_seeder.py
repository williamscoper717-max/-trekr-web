from seeds.adem import run as adem

def main():
    adem()

if __name__ == "__main__":
    main()