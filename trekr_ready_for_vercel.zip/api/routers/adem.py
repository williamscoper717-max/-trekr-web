from fastapi import APIRouter, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from services.adem import get_adems
from fastapi import Depends
import requests
from config import IMPACTCO2_API_KEY

router = APIRouter()

@router.get("/all")
async def adems(db: Session = Depends(get_db)):
    return await get_adems(db=db)

@router.get('/alimentation')
def get_alimentation(category: str = "group", language: str = "fr"):
    url = "https://impactco2.fr/api/v1/alimentation"
    params = {
        "category": category,
        "language": language
    }
    headers = {"Authorization": f"Bearer {IMPACTCO2_API_KEY}"}

    try:
        response = requests.get(url, params=params, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        raise HTTPException(status_code=500, detail=str(e))