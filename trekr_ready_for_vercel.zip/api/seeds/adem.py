from sqlalchemy.orm import Session
from database import SessionLocal
from models.adem import Adem

def run():
    db: Session = SessionLocal()
    if db.query(Adem).count() == 0:
        raw_data = [
            {"name": "food", "total_carbon": 728},
            {"name": "miscellaneous", "total_carbon": 1800},
            {"name": "housing", "total_carbon": 326},
            {"name": "social_services", "total_carbon": 784},
            {"name": "transportation", "total_carbon": 1500}
        ]
        for entry in raw_data:
            adem = Adem(**entry)
            db.add(adem)
        db.commit()
        print("✅ Adem data seeded successfully.")
    else:
        print("ℹ️ Adem data already exists.")
    db.close()