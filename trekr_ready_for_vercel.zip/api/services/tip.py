from sqlalchemy.orm import Session
from database import db_dependency
from fastapi.responses import JSONResponse
from models.tip import Tip
from fastapi import HTTPException, status

async def get_tip(trip_id: int, db: Session = db_dependency) -> JSONResponse:
    db_tip = db.query(Tip).filter(Tip.trip_id == trip_id).first()
    
    if not db_tip :
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tip not found"
        )
        
    tip_data = {
        "id": db_tip.id,
        "ecofriendly_tips": db_tip.ecofriendly_tips,
        "local_transport_options": db_tip.local_transport_options,
    }
    
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={"status": "success", "tip" : tip_data}
    )
    