from models.user import User, Base
from passlib.context import CryptContext
from database import engine, db_dependency,get_db
from sqlalchemy.exc import IntegrityError
from fastapi.responses import JSONResponse
from fastapi import HTTPException, status, Depends, UploadFile, File, Form
from emails.user import send_email
from services.code import create_code
from datetime import datetime, timedelta,timezone
from helpers import create_access_token, verify_password, generate_password, save_upload_file
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from config import SECRET_KEY, ALGORITHM, UPLOAD_DIR
from typing import Optional
import uuid
import os

Base.metadata.create_all(bind=engine)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Function to create a new user
async def create_user(user: User, db: Session) -> JSONResponse:
    # Input validation before database operations
    if not user.name or not user.email or not user.password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="All fields (name, email, password) are required"
        )
    
    # Check if the user already exists
    existing_user = db.query(User).filter(
        (User.email == user.email) | (User.phone == user.phone)
    ).first()

    if existing_user:
        if existing_user.email == user.email:
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={"status": "error", "message": "Adresse email déjà enregistré"}
            )
        if existing_user.phone == user.phone and user.phone is not None:
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={"status": "error", "message": "N° de téléphone déjà enregistré"}
            )
    
    # Hash the password securely
    hashed_password = pwd_context.hash(user.password)
    name = user.name.lower()
    email = user.email.lower()
    
    db_user = User(
        name=name,
        email=email,
        phone=user.phone,
        password=hashed_password
    )
    
    try:
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        
        # Generate and store the verification code
        verification_code = await create_code(user_id=db_user.id, db=db)
        
        # Send the verification code via email
        await send_email(
            subject="Inscription réussie",
            recipient=user.email,
            body=f"Veuillez vérifier votre compte en saisissant ce code : {verification_code}"
        )
        
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error: Unable to create user"
        )
    
    return JSONResponse(
        status_code=status.HTTP_201_CREATED,
        content={
            "status": "success",
            "message": f"Un email a été envoyé à votre boîte email {user.email}"
        }
    )

# Function to retrieve a user by ID
async def get_user(user_id: int, db: Session = db_dependency) -> JSONResponse:
    db_user = db.query(User).filter(User.id == user_id).first()
    
    if not db_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    if not db_user.email_verified_at:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email not verified"
        )
    
    # Check if an active token already exists
    if db_user.token and db_user.token_expiry > datetime.timestamp(datetime.now()):
        access_token = db_user.token
    else:
        # Generate and save a new access token
        access_token = create_access_token()
        db_user.token = access_token
        db_user.token_expiry = datetime.now() + timedelta(hours=1)
        db.commit()
        db.refresh(db_user)
    
    user_data = {
        "id": db_user.id,
        "name": db_user.name,
        "email": db_user.email,
        "phone": db_user.phone,
        "token": access_token,
    }
    
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={"status": "success", "user": user_data}
    )

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        print(f"Token received: {token}")   
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])

        # Try to extract user_id or email
        user_id = payload.get("sub")
        if not user_id:
            raise credentials_exception
        
        exp_timestamp = payload.get("exp")
        if not exp_timestamp:
            raise credentials_exception
        
        exp_datetime = datetime.fromtimestamp(exp_timestamp, tz=timezone.utc)
        print(f"Token expires at: {exp_datetime}")
        
        # Determine if sub is an int (traditional login) or string (Google login)
        if "@" in user_id:
            user = db.query(User).filter(User.email == user_id).first()
        else:
            user = db.query(User).filter(User.id == user_id).first()
        if user is None:
            raise credentials_exception

        return user

    except JWTError as e:
        print(f"JWTError: {e}")
        raise credentials_exception

async def create_google_user(name: str, email: str, db: Session) -> User:
    password = generate_password()
    hashed_password = pwd_context.hash(password)

    db_user = User(
        name=name.lower(),
        email=email.lower(),
        phone=None,
        password=hashed_password
    )

    try:
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        return db_user

    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error: Unable to create user"
        )
    
def create_jwt_token(user_email: str):
    # Example: You can add more claims to your token as needed
    expiration = datetime.now() + timedelta(days=30)
    payload = {
        "sub": user_email,
        "exp": expiration,
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
    return token

# Authenticate the user by validating the password
async def authenticate_user(email: str, password: str, db: Session = Depends(get_db)) -> Optional[User]:
    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Adresse email non enregistré"
        )
    if not verify_password(password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Mot de passe incorrect"
        )
    return user

async def update_user(
    id: int,
    name: Optional[str] = Form(None),
    email: Optional[str] = Form(None),
    phone: Optional[str] = Form(None),
    biography: Optional[str] = Form(None),
    password: Optional[str] = Form(None),
    picture: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    # Only hash password if provided
    if password:
        hashed_password = pwd_context.hash(password)
    else:
        hashed_password = None

    db_user = db.query(User).filter(User.id == id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")

    if name:
        db_user.name = name.lower()
    if email:
        db_user.email = email.lower()
    if phone is not None:
        db_user.phone = phone
    if biography is not None:
        db_user.biography = biography
    if hashed_password:
        db_user.password = hashed_password

    if picture:
        ext = os.path.splitext(picture.filename)[1]
        unique_filename = f"{uuid.uuid4()}{ext}"
        destination = os.path.join(UPLOAD_DIR, unique_filename)
        await save_upload_file(picture, destination)
        db_user.picture = unique_filename

    db.commit()
    db.refresh(db_user)

    return db_user