from fastapi import HTTPException, status
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from database import db_dependency
from models.adem import Adem

async def get_adems(db:Session = db_dependency)-> JSONResponse:
    db_adems = db.query(Adem).all()
    
    if not db_adems:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Adem not found"
        )
    
    adem_data_list = [
        {
            "id": adem.id,
            "name": adem.name,
            "total": adem.total_carbon,
        }
        for adem in db_adems
    ]
    
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content={"status": "success", "adems": adem_data_list}
    )