from database import Base
from sqlalchemy import Column, Integer, String, Text, TIMESTAMP, text, ForeignKey, Date, Boolean, Float, Numeric
from sqlalchemy.orm import relationship

class Trip(Base):
    __tablename__ = "trips"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    type = Column(String, index=True)
    country = Column(String, index=True)
    destination = Column(String, index=True)
    transportation = Column(String, index=True)
    image = Column(String, index=True, nullable=True)
    status = Column(String, index=True, server_default=text("'En cours'"))
    language = Column(String, index=True)
    budget = Column(Integer, index=True)
    start_date = Column(Date, index=True)
    end_date = Column(Date, index=True)
    num_adult = Column(Integer)
    num_children = Column(Integer, nullable=True)
    note = Column(Text, nullable=True)
    carbon_emission = Column(Float, nullable=True)
    with_visa = Column(Boolean, index=False)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    created_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'))
    updated_at = Column(TIMESTAMP(timezone=True), server_default=text('now()'), server_onupdate=text('now()'))

    user = relationship('User', back_populates='trips')
    programs = relationship("Program", back_populates="trip", cascade="all, delete-orphan")
    tips = relationship("Tip", back_populates="trip", cascade="all, delete-orphan")