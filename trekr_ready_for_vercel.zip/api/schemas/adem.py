from pydantic import BaseModel

class AdemOut(BaseModel):
    id: int
    name: str
    total_carbon: int

    class Config:
        from_attributes = True