export const url = window.location.hostname === "localhost" ? "http://127.0.0.1:8000" : "/api";
