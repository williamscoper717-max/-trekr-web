import './App.css'
import Layout from "./components/navbar/layout"

function App() {
  return (
    <>
      <Layout />
    </>
  )
}

export default App
